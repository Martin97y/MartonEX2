Do not remove Scripts folder
If you cant run MartonEX turn off antivirus

If you need update,update it by using MartonEX_Launcher.


Have Fun :)